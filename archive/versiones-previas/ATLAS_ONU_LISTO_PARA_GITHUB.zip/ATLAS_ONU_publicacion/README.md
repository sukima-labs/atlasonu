# ATLAS ONU — Arqueología Documental

**Autor y responsable del proyecto:** Jeisson Arley Osorio Mesa.

Herramienta académica de exploración de procedimientos especiales de las Naciones Unidas, mandatos, documentos y nomenclatura de resoluciones. Desarrollo independiente; no representa una herramienta oficial de la ONU ni de la Universidad de Alcalá.

## Abrir el tablero

Abrir `index.html` en un navegador moderno. Para publicarlo en GitHub Pages, colocar este proyecto en un repositorio público y habilitar Pages sobre la rama principal, carpeta raíz (`/`).

## Funciones incluidas

- Búsqueda de mandatos por palabra clave y filtros.
- Fichas de mandatos e información contextual.
- Arqueología documental y guía de símbolos ONU.
- Información sobre selección de titulares.
- Gráficos basados en registros de muestra y alertas de verificación.
- Exportación de resultados CSV desde el navegador.

## Limitaciones y estado de verificación

**Versión de demostración, no catálogo definitivo.** La muestra contiene 28 mandatos y 11 registros de trazabilidad. Algunos registros históricos requieren cotejo con los documentos originales. La actualización automática por internet, los mapas y un sistema de auditoría jurídica exhaustiva no están implementados. Los gráficos representan la muestra incorporada, no el universo de mandatos vigentes.

No usar esta herramienta como única fuente para citas académicas o jurídicas. Confirmar cada documento en la Biblioteca Digital de Naciones Unidas, OHCHR o la fuente oficial correspondiente.

## Licencias y atribución

Copyright © 2026 Jeisson Arley Osorio Mesa. Todos los derechos reservados hasta que el autor elija una licencia de reutilización. La disponibilidad pública de un repositorio no implica autorización general de reutilización de su código.

Los símbolos, denominaciones y documentos de Naciones Unidas pertenecen a sus respectivos marcos institucionales. Las fuentes originales se citan mediante sus enlaces.
