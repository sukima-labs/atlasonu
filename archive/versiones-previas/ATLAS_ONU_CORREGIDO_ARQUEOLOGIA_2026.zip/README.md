# ATLAS ONU — Arqueología documental

**Autor:** Jeisson Arley Osorio Mesa · 2026. Proyecto académico independiente.

## Abrir

Abrir `index.html` desde Chrome, Edge, Firefox o Safari; no requiere instalar código. Para páginas web públicas se puede alojar con GitHub Pages.

## Qué funciona

- Navegación local, catálogo y búsqueda por palabras, figura y órgano.
- Traces históricas con alertas, nomenclatura ONU y explicación de selección de relatores.
- Módulo **Recuperar documentos**: permite identificar el acto jurídico frente al informe que lo reproduce; buscar por símbolo y tema; ofrece rutas de acceso alternativas y un ejemplo comprobado (Comisión de Derechos Humanos, resolución 20 (XXXVI) de 1980, en E/1980/13–E/CN.4/1408, pp. 180–181).
- Panel estadístico limitado a la muestra de 28 mandatos; no corresponde al universo completo de ONU.

## No implementado ni acreditado

- Descarga o recuperación automática masiva de PDFs y cotejo integral de documentos históricos.
- Sincronización automática de mandatos, titulares, informes y cifras con servidores externos.
- Mapas geográficos, permisos diferenciados y catalogación exhaustiva.
- Validación jurídica del 100% de referencias o enlaces.

El módulo de recuperación sugiere varias rutas oficiales, pero **una ruta no es un documento recuperado**. No afirmar que un enlace está verificado sin cotejar el texto y metadatos del documento primario. Los documentos históricos podrían estar integrados en informes de sesión o no digitalizados.

## Fuentes

- ONU Biblioteca Digital: https://digitallibrary.un.org/
- ONU Documentos: https://docs.un.org/
- UN Library, búsqueda: https://research.un.org/en/docs/find/documents
- Registro histórico del WGEID: https://digitallibrary.un.org/record/96859?ln=en

## Autoría

© 2026 Jeisson Arley Osorio Mesa. Todos los derechos reservados. La publicación pública por sí misma no constituye licencia abierta. Este trabajo no representa ni está avalado por la ONU o la Universidad de Alcalá.
